package com.github.chaymakhlifi.katabank;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;



public final class Statement {
    
    private final List<StatementItem> statementItems = new ArrayList<>();

    public List<StatementItem> getStatementItems() {
        return Collections.unmodifiableList(this.statementItems);
    }
    public void addTransaction(final Transaction transaction) {
        this.statementItems.add(new StatementItem(transaction, this.getBalance() + transaction.getAmount()));
    }

    public double getBalance() {
        return this.statementItems.isEmpty() ? 0 : this.statementItems.get(this.statementItems.size() - 1).getBalance();
        
    } 

    public String print() {
        final StringBuilder sb = new StringBuilder();
        for (final StatementItem statementItem : this.statementItems) {
            sb.append(statementItem.getTransaction().getDate()).append(" ");
            sb.append(statementItem.getTransaction().getOperation()).append(" ");
            sb.append(statementItem.getTransaction().getAmount()).append(" ");
            sb.append(statementItem.getBalance());
            sb.append("\n");
        }
        return sb.toString();
    }
  

}
