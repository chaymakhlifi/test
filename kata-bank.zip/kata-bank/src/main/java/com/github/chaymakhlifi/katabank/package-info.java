/**
 * Filename     : package-info.java
 */
/**
 * <p>package-info. </p>
 *
 * @author chayma
 *
 */
package com.github.chaymakhlifi.katabank;
