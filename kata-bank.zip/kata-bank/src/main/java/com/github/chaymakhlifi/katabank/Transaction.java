package com.github.chaymakhlifi.katabank;

import java.time.LocalDateTime;

public final class Transaction {
    
    public static final String DEPOSIT = "DEPOSIT";
    public static final String WITHDRAWAL = "WITHDRAWAL";
    private final double amount;
    private final LocalDateTime date;
    private final String operation;

    public Transaction(final double aAmount, final LocalDateTime aDate) {
        super();
        this.amount = aAmount;
        this.date = aDate;
        this.operation = (aAmount >= 0) ? DEPOSIT : WITHDRAWAL;
    }

    public double getAmount() {
        return this.amount;
    }
    public LocalDateTime getDate() {
        return this.date;
    }
    public String getOperation() {
        return this.operation;
    }

}
