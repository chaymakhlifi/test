package com.github.chaymakhlifi.katabank;

import java.time.LocalDateTime;


public final class Account {

    private final Statement statement = new Statement();

    public Account deposit(final double aAmount, final LocalDateTime aDate) {
        this.statement.addTransaction(new Transaction(aAmount, aDate));
        return this; 
    }

    public Account deposit(double aAmount) {
        deposit(aAmount, LocalDateTime.now());
        return this;
    }

    public Account withdraw(double aAmount, LocalDateTime aDate) {
        this.statement.addTransaction(new Transaction(-aAmount, aDate));
        return this;
    }

    public Account withdraw(double aAmount) {
        withdraw(aAmount, LocalDateTime.now());
        return this;
    }

    public Statement getStatement() {
        return this.statement;
    }

    
}
