package com.github.chaymakhlifi.katabank;


public final class StatementItem {
    
    private final Transaction transaction;
    private final double balance;

    public StatementItem(final Transaction aTransaction, final double aBalance) {
        super();
        this.transaction = aTransaction;
        this.balance = aBalance;
    }

    public Transaction getTransaction() {
        return this.transaction;
    }
    public double getBalance() {
        return this.balance;
    }
    
}
